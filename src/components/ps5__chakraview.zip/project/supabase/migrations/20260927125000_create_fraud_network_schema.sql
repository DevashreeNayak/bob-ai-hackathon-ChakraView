/*
# Create cyber fraud network analyzer schema (single-tenant, no auth)

1. New Tables
- `fraud_cases`: A cyber fraud investigation case. Stores case title, fraud type, jurisdiction, investigating officer, raw intelligence text, and generated FIR brief.
- `entities`: Extracted entities from raw intelligence — persons, bank accounts, phone numbers, SIM/IMEI, devices, UPI IDs, addresses. Each has a type, label, and risk score.
- `relationships`: Connections between entities — e.g., "owns", "transfers_to", "calls", "uses_device", "registered_at". Has source entity, target entity, relationship type, and transaction count/amount if applicable.
- `timeline_events`: Chronological events extracted from intelligence — transactions, calls, SIM swaps, registrations. Each has timestamp, event type, and involved entities.

2. Security
- RLS enabled on all tables. Single-tenant (no sign-in): anon + authenticated CRUD with USING(true)/WITH CHECK(true).
*/

CREATE TABLE IF NOT EXISTS fraud_cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  fraud_type text,
  jurisdiction text,
  officer_name text,
  raw_intelligence text,
  fir_brief text,
  status text DEFAULT 'analyzing',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE fraud_cases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_fraud_cases" ON fraud_cases;
CREATE POLICY "anon_select_fraud_cases" ON fraud_cases FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_fraud_cases" ON fraud_cases;
CREATE POLICY "anon_insert_fraud_cases" ON fraud_cases FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_fraud_cases" ON fraud_cases;
CREATE POLICY "anon_update_fraud_cases" ON fraud_cases FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_fraud_cases" ON fraud_cases;
CREATE POLICY "anon_delete_fraud_cases" ON fraud_cases FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS entities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES fraud_cases(id) ON DELETE CASCADE,
  entity_type text NOT NULL,
  label text NOT NULL,
  risk_score integer DEFAULT 0,
  role text,
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE entities ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_entities" ON entities;
CREATE POLICY "anon_select_entities" ON entities FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_entities" ON entities;
CREATE POLICY "anon_insert_entities" ON entities FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_entities" ON entities;
CREATE POLICY "anon_update_entities" ON entities FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_entities" ON entities;
CREATE POLICY "anon_delete_entities" ON entities FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_entities_case_id ON entities(case_id);

CREATE TABLE IF NOT EXISTS relationships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES fraud_cases(id) ON DELETE CASCADE,
  source_entity_id uuid NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
  target_entity_id uuid NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
  rel_type text NOT NULL,
  amount numeric,
  transaction_count integer,
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE relationships ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_relationships" ON relationships;
CREATE POLICY "anon_select_relationships" ON relationships FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_relationships" ON relationships;
CREATE POLICY "anon_insert_relationships" ON relationships FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_relationships" ON relationships;
CREATE POLICY "anon_delete_relationships" ON relationships FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_relationships_case_id ON relationships(case_id);
CREATE INDEX IF NOT EXISTS idx_relationships_source ON relationships(source_entity_id);
CREATE INDEX IF NOT EXISTS idx_relationships_target ON relationships(target_entity_id);

CREATE TABLE IF NOT EXISTS timeline_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES fraud_cases(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  description text NOT NULL,
  event_date date,
  entity_ids text[],
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE timeline_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_timeline" ON timeline_events;
CREATE POLICY "anon_select_timeline" ON timeline_events FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_timeline" ON timeline_events;
CREATE POLICY "anon_insert_timeline" ON timeline_events FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_timeline" ON timeline_events;
CREATE POLICY "anon_delete_timeline" ON timeline_events FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_timeline_case_id ON timeline_events(case_id);
