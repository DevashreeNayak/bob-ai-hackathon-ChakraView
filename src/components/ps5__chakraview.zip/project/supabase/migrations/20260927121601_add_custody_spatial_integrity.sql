/*
# Add chain-of-custody, spatial mapping, and integrity features

1. Modified Tables
- `evidence_items`: Added `scene_x` (float), `scene_y` (float) for plotting items on a 2D crime scene map. Added `integrity_hash` (text) for tamper-evident cryptographic hash of the evidence record. Added `degradation_deadline` (timestamptz) for biological/trace evidence that degrades over time.

2. New Tables
- `custody_events`: A tamper-evident chain-of-custody log for each evidence item. Every transfer, test, or status change is recorded with handler name, action type, timestamp, and a hash linking to the previous event — creating an unbreakable audit trail for court admissibility.
- `case_links`: Cross-case evidence linkage records. When the system detects that evidence in one case may be linked to evidence in another (same category, similar description, or spatial proximity), it stores the linkage here with a match score and rationale.

3. Security
- RLS enabled on all new tables with anon+authenticated CRUD (single-tenant demo app).
*/

ALTER TABLE evidence_items
  ADD COLUMN IF NOT EXISTS scene_x float,
  ADD COLUMN IF NOT EXISTS scene_y float,
  ADD COLUMN IF NOT EXISTS integrity_hash text,
  ADD COLUMN IF NOT EXISTS degradation_deadline timestamptz;

CREATE TABLE IF NOT EXISTS custody_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  evidence_id uuid NOT NULL REFERENCES evidence_items(id) ON DELETE CASCADE,
  action text NOT NULL,
  handler_name text NOT NULL,
  notes text,
  event_hash text,
  previous_hash text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE custody_events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_custody" ON custody_events;
CREATE POLICY "anon_select_custody" ON custody_events FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_custody" ON custody_events;
CREATE POLICY "anon_insert_custody" ON custody_events FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_custody" ON custody_events;
CREATE POLICY "anon_delete_custody" ON custody_events FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_custody_evidence_id ON custody_events(evidence_id);

CREATE TABLE IF NOT EXISTS case_links (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_a_id uuid NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  case_b_id uuid NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  evidence_a_id uuid REFERENCES evidence_items(id) ON DELETE CASCADE,
  evidence_b_id uuid REFERENCES evidence_items(id) ON DELETE CASCADE,
  match_score integer NOT NULL,
  link_type text NOT NULL,
  rationale text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE case_links ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_links" ON case_links;
CREATE POLICY "anon_select_links" ON case_links FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_links" ON case_links;
CREATE POLICY "anon_insert_links" ON case_links FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_links" ON case_links;
CREATE POLICY "anon_delete_links" ON case_links FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_case_links_a ON case_links(case_a_id);
CREATE INDEX IF NOT EXISTS idx_case_links_b ON case_links(case_b_id);
