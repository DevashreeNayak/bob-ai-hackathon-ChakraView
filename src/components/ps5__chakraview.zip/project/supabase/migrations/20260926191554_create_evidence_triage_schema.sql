/*
# Create evidence triage schema (single-tenant, no auth)

1. New Tables
- `cases`: a forensic case / crime scene triage session. Stores the crime type, location, examiner name, and case title. One case holds many evidence items.
- `evidence_items`: individual items logged at a crime scene. Stores the item description, quantity, collection location, and the triage results produced by the analysis engine (category, priority score, urgency flag, recommended test, rationale, and rank order).

2. Relationships
- `evidence_items.case_id` → `cases.id` (CASCADE on delete).

3. Security
- Enable RLS on both tables.
- Single-tenant app (no sign-in screen): policies use `TO anon, authenticated` with `USING (true)` / `WITH CHECK (true)` because the data is intentionally shared/public for the demo.
*/

CREATE TABLE IF NOT EXISTS cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  crime_type text NOT NULL,
  location text,
  examiner_name text,
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cases ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_cases" ON cases;
CREATE POLICY "anon_select_cases" ON cases FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_cases" ON cases;
CREATE POLICY "anon_insert_cases" ON cases FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_cases" ON cases;
CREATE POLICY "anon_update_cases" ON cases FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_cases" ON cases;
CREATE POLICY "anon_delete_cases" ON cases FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS evidence_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  description text NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  collection_location text,
  category text,
  priority_score integer,
  urgency_flag boolean DEFAULT false,
  recommended_test text,
  rationale text,
  rank_order integer,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE evidence_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_evidence" ON evidence_items;
CREATE POLICY "anon_select_evidence" ON evidence_items FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_evidence" ON evidence_items;
CREATE POLICY "anon_insert_evidence" ON evidence_items FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_evidence" ON evidence_items;
CREATE POLICY "anon_update_evidence" ON evidence_items FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_evidence" ON evidence_items;
CREATE POLICY "anon_delete_evidence" ON evidence_items FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_evidence_items_case_id ON evidence_items(case_id);
CREATE INDEX IF NOT EXISTS idx_evidence_items_rank ON evidence_items(rank_order);
