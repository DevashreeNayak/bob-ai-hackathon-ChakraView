import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type FraudCase = {
  id: string
  title: string
  fraud_type: string | null
  jurisdiction: string | null
  officer_name: string | null
  raw_intelligence: string | null
  fir_brief: string | null
  status: string | null
  created_at: string
}

export type Entity = {
  id: string
  case_id: string
  entity_type: string
  label: string
  risk_score: number | null
  role: string | null
  metadata: Record<string, any> | null
  created_at: string
}

export type Relationship = {
  id: string
  case_id: string
  source_entity_id: string
  target_entity_id: string
  rel_type: string
  amount: number | null
  transaction_count: number | null
  metadata: Record<string, any> | null
  created_at: string
}

export type TimelineEvent = {
  id: string
  case_id: string
  event_type: string
  description: string
  event_date: string | null
  entity_ids: string[] | null
  metadata: Record<string, any> | null
  created_at: string
}
