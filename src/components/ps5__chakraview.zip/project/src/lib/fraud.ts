export type EntityType =
  | 'person' | 'bank_account' | 'phone' | 'sim_imei' | 'device' | 'upi_id' | 'address' | 'organization'

export const ENTITY_META: Record<EntityType, { label: string; icon: string; color: string }> = {
  person: { label: 'Person', icon: '👤', color: 'cyan' },
  bank_account: { label: 'Bank Account', icon: '🏦', color: 'emerald' },
  phone: { label: 'Phone Number', icon: '📱', color: 'sky' },
  sim_imei: { label: 'SIM / IMEI', icon: '📲', color: 'amber' },
  device: { label: 'Device', icon: '💻', color: 'violet' },
  upi_id: { label: 'UPI ID', icon: '💸', color: 'rose' },
  address: { label: 'Address', icon: '📍', color: 'orange' },
  organization: { label: 'Organization', icon: '🏢', color: 'slate' },
}

export type RelationshipType =
  | 'owns' | 'transfers_to' | 'calls' | 'uses_device' | 'registered_at' | 'linked_to' | 'operates' | 'reports_to'

export const REL_META: Record<RelationshipType, { label: string; color: string; dashed: boolean }> = {
  owns: { label: 'owns', color: '#34d399', dashed: false },
  transfers_to: { label: 'transfers to', color: '#f43f5e', dashed: false },
  calls: { label: 'calls', color: '#38bdf8', dashed: false },
  uses_device: { label: 'uses device', color: '#a78bfa', dashed: false },
  registered_at: { label: 'registered at', color: '#fb923c', dashed: false },
  linked_to: { label: 'linked to', color: '#6b8299', dashed: true },
  operates: { label: 'operates', color: '#fbbf24', dashed: false },
  reports_to: { label: 'reports to', color: '#f472b6', dashed: false },
}

export type ExtractedEntity = {
  type: EntityType
  label: string
  riskScore: number
  role: string
  metadata: Record<string, string>
}

export type ExtractedRelationship = {
  sourceLabel: string
  targetLabel: string
  type: RelationshipType
  amount?: number
  transactionCount?: number
}

export type TimelineEvent = {
  eventType: string
  description: string
  date: string | null
  entityLabels: string[]
}

export type FraudPattern = {
  type: string
  label: string
  description: string
  confidence: number
}

export type AnalysisResult = {
  entities: ExtractedEntity[]
  relationships: ExtractedRelationship[]
  timeline: TimelineEvent[]
  patterns: FraudPattern[]
  hierarchy: { kingpins: string[]; mules: string[]; victims: string[] }
  firBrief: string
}

const PHONE_RE = /(\+?91[\s-]?)?([6-9]\d{9})\b/g
const BANK_ACCT_RE = /\b(\d{9,18})\b\s*(?:A\/C|account|a\/c no|account no\.?)?/gi
const IMEI_RE = /\b(\d{15})\b/g
const UPI_RE = /\b([\w.-]+@[\w.-]+)\b/g
const AMOUNT_RE = /(?:Rs\.?|INR|₹)\s*([\d,]+(?:\.\d{1,2})?)/gi
const DATE_RE = /(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})|(\d{4}-\d{2}-\d{2})/g

const FRAUD_KEYWORDS: Record<string, string[]> = {
  sim_swap: ['sim swap', 'sim replacement', 'duplicate sim', 'otp', 'otp fraud', 'sim cloning'],
  upi_fraud: ['upi', 'qr code', 'scan', 'payment link', 'collect request', 'gpay', 'phonepe', 'paytm'],
  phishing: ['phishing', 'otp', 'link', 'verification', 'kyc', 'account suspend', 'otp share'],
  sextortion: ['sextortion', 'blackmail', 'video call', 'nude', 'compromising', 'recording'],
  investment_fraud: ['investment', 'trading', 'bitcoin', 'crypto', 'doubling', 'returns', 'profit'],
  job_fraud: ['job', 'work from home', 'telegram', 'commission', 'task', 'registration fee'],
}

const ROLE_KEYWORDS: {
  kingpin: string[]
  mule: string[]
  victim: string[]
} = {
  kingpin: ['kingpin', 'mastermind', 'main accused', 'ringleader', 'operates', 'controls', 'directs', 'manages', 'runs the', 'head of'],
  mule: ['mule', 'on behalf of', 'for someone', 'lent account', 'gave account', 'sold account', 'proxy', 'courier', 'withdraw', 'cash deposit', 'on commission'],
  victim: ['victim', 'complainant', 'defrauded', 'lost', 'cheated', 'transferred to', 'paid', 'received call from'],
}

function detectFraudPatterns(text: string): FraudPattern[] {
  const lower = text.toLowerCase()
  const patterns: FraudPattern[] = []

  for (const [type, keywords] of Object.entries(FRAUD_KEYWORDS)) {
    const hits = keywords.filter((k) => lower.includes(k))
    if (hits.length > 0) {
      const confidence = Math.min(95, 40 + hits.length * 15)
      const labels: Record<string, string> = {
        sim_swap: 'SIM Swap Fraud',
        upi_fraud: 'UPI Payment Fraud',
        phishing: 'OTP Phishing',
        sextortion: 'Sextortion / Blackmail',
        investment_fraud: 'Investment Scam',
        job_fraud: 'Fake Job / Task Scam',
      }
      patterns.push({
        type,
        label: labels[type] || type,
        description: `Detected ${hits.length} indicator(s): "${hits.join('", "')}". This pattern involves ${describePattern(type)}.`,
        confidence,
      })
    }
  }

  return patterns.sort((a, b) => b.confidence - a.confidence)
}

function describePattern(type: string): string {
  const descs: Record<string, string> = {
    sim_swap: 'unauthorized SIM replacement to intercept OTPs and drain bank accounts',
    upi_fraud: 'fraudulent UPI payment requests or QR codes to trick victims into transferring money',
    phishing: 'social engineering to extract OTPs and banking credentials from victims',
    sextortion: 'recording compromising video calls and blackmailing victims for payment',
    investment_fraud: 'promising unrealistic returns on fake trading/crypto platforms',
    job_fraud: 'offering fake work-from-home jobs requiring upfront registration fees',
  }
  return descs[type] || 'coordinated fraudulent activity'
}

function extractEntities(text: string): ExtractedEntity[] {
  const entities: ExtractedEntity[] = []
  const seen = new Set<string>()

  const addEntity = (type: EntityType, label: string, riskScore: number = 0, role: string = '', metadata: Record<string, string> = {}) => {
    const key = `${type}:${label}`
    if (seen.has(key)) return
    seen.add(key)
    entities.push({ type, label, riskScore, role, metadata })
  }

  const lower = text.toLowerCase()

  const phones = text.match(PHONE_RE) || []
  phones.forEach((p) => {
    const clean = p.replace(/[\s\-+]/g, '')
    const role = inferRole(text, p, lower)
    addEntity('phone', clean.slice(-10), role === 'kingpin' ? 85 : role === 'mule' ? 60 : 30, role, { raw: p.trim() })
  })

  const upis = text.match(UPI_RE) || []
  upis.forEach((u) => {
    if (u.length < 6 || u.includes('@gmail.com') || u.includes('@yahoo') || u.includes('@outlook')) return
    const role = inferRole(text, u, lower)
    addEntity('upi_id', u, role === 'kingpin' ? 80 : role === 'mule' ? 55 : 25, role)
  })

  const amounts = [...text.matchAll(AMOUNT_RE)]
  const bankAccts = [...text.matchAll(BANK_ACCT_RE)]
  bankAccts.forEach((m) => {
    const acct = m[1]
    if (acct.length < 9 || acct.length > 18) return
    if (/^\d{4}$/.test(acct)) return
    const role = inferRole(text, acct, lower)
    addEntity('bank_account', acct, role === 'kingpin' ? 75 : role === 'mule' ? 50 : 20, role)
  })

  const imeis = text.match(IMEI_RE) || []
  imeis.forEach((i) => {
    if (i.length !== 15) return
    addEntity('sim_imei', i, 70, '', { type: 'IMEI' })
  })

  const namePatterns = [
    /(?:accused|suspect|named|one)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})/g,
    /(?:kingpin|mastermind|ringleader)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})/g,
    /(?:victim|complainant)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})/g,
    /(?:mule|proxy)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})/g,
    /([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,2})\s+(?:is|was|has|operates|controls|transferred|received|called|owns)/g,
  ]

  namePatterns.forEach((pat) => {
    const matches = [...text.matchAll(pat)]
    matches.forEach((m) => {
      const name = m[1]?.trim()
      if (!name || name.length < 4) return
      if (['The', 'This', 'Case', 'FIR', 'Police', 'Court', 'Section', 'Act'].includes(name)) return
      const role = inferRole(text, name, lower)
      addEntity('person', name, role === 'kingpin' ? 90 : role === 'mule' ? 50 : 35, role)
    })
  })

  const addressPat = /(?:address|resides at|located at|from)\s+(.+?)(?:\.|,|\n|$)/gi
  const addrMatches = [...text.matchAll(addressPat)]
  addrMatches.forEach((m) => {
    const addr = m[1]?.trim()
    if (addr && addr.length > 5 && addr.length < 100) {
      addEntity('address', addr, 20, '')
    }
  })

  return entities
}

function inferRole(fullText: string, entityText: string, lowerFull: string): string {
  const ctx = getContext(fullText, entityText, 80)
  const lowerCtx = ctx.toLowerCase()

  for (const [role, keywords] of Object.entries(ROLE_KEYWORDS)) {
    for (const kw of keywords) {
      if (lowerCtx.includes(kw)) return role
    }
  }
  return ''
}

function getContext(fullText: string, entityText: string, radius: number): string {
  const idx = fullText.indexOf(entityText)
  if (idx === -1) return ''
  const start = Math.max(0, idx - radius)
  const end = Math.min(fullText.length, idx + entityText.length + radius)
  return fullText.slice(start, end)
}

function extractRelationships(
  text: string,
  entities: ExtractedEntity[],
): ExtractedRelationship[] {
  const rels: ExtractedRelationship[] = []
  const lower = text.toLowerCase()

  const transferPat = /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(?:transferred|sent|paid|deposited)\s+(?:Rs\.?|INR|₹)?\s*([\d,]+)\s*(?:to|into)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?|[\d]{9,18})/gi
  const transferMatches = [...text.matchAll(transferPat)]
  transferMatches.forEach((m) => {
    const amount = parseInt(m[2]?.replace(/,/g, '') || '0')
    rels.push({
      sourceLabel: m[1].trim(),
      targetLabel: m[3].trim(),
      type: 'transfers_to',
      amount,
      transactionCount: 1,
    })
  })

  const callsPat = /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(?:called|contacted|phoned)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?|\+?\d{10,12})/gi
  const callsMatches = [...text.matchAll(callsPat)]
  callsMatches.forEach((m) => {
    rels.push({ sourceLabel: m[1].trim(), targetLabel: m[2].trim(), type: 'calls' })
  })

  const ownsPat = /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(?:owns|has|holds|possesses)\s+(?:a\s+)?(?:bank\s+)?(?:account|phone|SIM|device|number)\s*([\d]+)/gi
  const ownsMatches = [...text.matchAll(ownsPat)]
  ownsMatches.forEach((m) => {
    rels.push({ sourceLabel: m[1].trim(), targetLabel: m[2].trim(), type: 'owns' })
  })

  const reportsPat = /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(?:reports to|works for|answers to|on behalf of)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/gi
  const reportsMatches = [...text.matchAll(reportsPat)]
  reportsMatches.forEach((m) => {
    rels.push({ sourceLabel: m[1].trim(), targetLabel: m[2].trim(), type: 'reports_to' })
  })

  const operatesPat = /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(?:operates|controls|manages|runs)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/gi
  const operatesMatches = [...text.matchAll(operatesPat)]
  operatesMatches.forEach((m) => {
    rels.push({ sourceLabel: m[1].trim(), targetLabel: m[2].trim(), type: 'operates' })
  })

  const linkedPat = /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(?:linked to|connected to|associated with)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/gi
  const linkedMatches = [...text.matchAll(linkedPat)]
  linkedMatches.forEach((m) => {
    rels.push({ sourceLabel: m[1].trim(), targetLabel: m[2].trim(), type: 'linked_to' })
  })

  return rels
}

function extractTimeline(text: string, entities: ExtractedEntity[]): TimelineEvent[] {
  const events: TimelineEvent[] = []
  const dateMatches = [...text.matchAll(DATE_RE)]

  const transferPat = /(?:on|dated)\s+(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}|\d{4}-\d{2}-\d{2}),?\s*(.+?)(?:\.|\n|$)/gi
  const tMatches = [...text.matchAll(transferPat)]
  tMatches.forEach((m) => {
    events.push({
      eventType: 'transaction',
      description: m[2]?.trim() || 'Transaction occurred',
      date: m[1],
      entityLabels: entities.filter((e) => m[2]?.includes(e.label)).map((e) => e.label),
    })
  })

  const simSwapPat = /(?:sim swap|sim replacement|duplicate sim|sim cloning)(?:\s+(?:on|dated|of)\s+(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}|\d{4}-\d{2}-\d{2}))?/gi
  const simMatches = [...text.matchAll(simSwapPat)]
  simMatches.forEach((m) => {
    events.push({
      eventType: 'sim_swap',
      description: 'SIM swap/replacement detected',
      date: m[1] || null,
      entityLabels: [],
    })
  })

  const callPat = /(?:call|contact|phone)(?:ed)?\s+(?:on|dated)\s+(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/gi
  const callMatches = [...text.matchAll(callPat)]
  callMatches.forEach((m) => {
    events.push({
      eventType: 'call',
      description: 'Communication contact made',
      date: m[1],
      entityLabels: [],
    })
  })

  if (dateMatches.length > 0 && events.length === 0) {
    dateMatches.forEach((m) => {
      const ctx = getContext(text, m[0], 60)
      events.push({
        eventType: 'event',
        description: ctx.trim() || m[0],
        date: m[0],
        entityLabels: entities.filter((e) => ctx.includes(e.label)).map((e) => e.label),
      })
    })
  }

  return events.sort((a, b) => {
    if (!a.date) return 1
    if (!b.date) return -1
    return new Date(a.date).getTime() - new Date(b.date).getTime()
  })
}

function inferHierarchy(entities: ExtractedEntity[], relationships: ExtractedRelationship[]): {
  kingpins: string[]
  mules: string[]
  victims: string[]
} {
  const kingpins = new Set<string>()
  const mules = new Set<string>()
  const victims = new Set<string>()

  entities.forEach((e) => {
    if (e.role === 'kingpin') kingpins.add(e.label)
    if (e.role === 'mule') mules.add(e.label)
    if (e.role === 'victim') victims.add(e.label)
  })

  relationships.forEach((r) => {
    if (r.type === 'reports_to' || r.type === 'operates') kingpins.add(r.targetLabel)
    if (r.type === 'transfers_to') {
      const targetEntity = entities.find((e) => e.label === r.targetLabel)
      if (targetEntity && targetEntity.riskScore > 60) kingpins.add(r.targetLabel)
      else mules.add(r.targetLabel)
      const sourceEntity = entities.find((e) => e.label === r.sourceLabel)
      if (sourceEntity && sourceEntity.role === 'victim') victims.add(r.sourceLabel)
    }
  })

  entities.forEach((e) => {
    if (e.riskScore >= 75 && !kingpins.has(e.label) && !mules.has(e.label)) {
      kingpins.add(e.label)
    }
  })

  return {
    kingpins: [...kingpins],
    mules: [...mules],
    victims: [...victims],
  }
}

function generateFIRBrief(
  patterns: FraudPattern[],
  hierarchy: { kingpins: string[]; mules: string[]; victims: string[] },
  entities: ExtractedEntity[],
  relationships: ExtractedRelationship[],
): string {
  const lines: string[] = []

  lines.push('FIR-READY CASE BRIEF — CYBER FRAUD INVESTIGATION')
  lines.push('================================================')
  lines.push('')

  lines.push('1. FRAUD PATTERN IDENTIFIED')
  lines.push('--------------------------')
  patterns.forEach((p, i) => {
    lines.push(`   ${i + 1}. ${p.label} (${p.confidence}% confidence)`)
    lines.push(`      ${p.description}`)
  })
  if (patterns.length === 0) lines.push('   Pattern analysis inconclusive — manual review required.')
  lines.push('')

  lines.push('2. ORGANIZATIONAL HIERARCHY')
  lines.push('--------------------------')
  lines.push(`   KINGPIN / MASTERMIND: ${hierarchy.kingpins.length > 0 ? hierarchy.kingpins.join(', ') : 'Not yet identified'}`)
  lines.push(`   MULES / PROXIES: ${hierarchy.mules.length > 0 ? hierarchy.mules.join(', ') : 'None identified'}`)
  lines.push(`   VICTIMS: ${hierarchy.victims.length > 0 ? hierarchy.victims.join(', ') : 'Not yet identified'}`)
  lines.push('')

  lines.push('3. KEY ENTITIES EXTRACTED')
  lines.push('-------------------------')
  entities.slice(0, 15).forEach((e) => {
    lines.push(`   ${ENTITY_META[e.type].icon} ${e.label} [${ENTITY_META[e.type].label}] — Risk: ${e.riskScore}/100${e.role ? `, Role: ${e.role}` : ''}`)
  })
  lines.push('')

  lines.push('4. FINANCIAL FLOWS')
  lines.push('------------------')
  const transfers = relationships.filter((r) => r.type === 'transfers_to')
  if (transfers.length > 0) {
    let totalAmount = 0
    transfers.forEach((t) => {
      const amt = t.amount || 0
      totalAmount += amt
      lines.push(`   ${t.sourceLabel} → ${t.targetLabel}: Rs. ${amt.toLocaleString('en-IN')}`)
    })
    lines.push(`   TOTAL TRACED FLOW: Rs. ${totalAmount.toLocaleString('en-IN')}`)
  } else {
    lines.push('   No explicit financial flows extracted from intelligence.')
  }
  lines.push('')

  lines.push('5. RECOMMENDED ACTIONS')
  lines.push('---------------------')
  const actions: string[] = []
  if (patterns.some((p) => p.type === 'sim_swap')) {
    actions.push('Request CDR (Call Detail Records) for all identified phone numbers from respective telecom operators')
    actions.push('Issue preservation notice to telecom operator for SIM swap records and IP logs')
  }
  if (patterns.some((p) => p.type === 'upi_fraud')) {
    actions.push('Raise chargeback/dispute requests with respective payment gateways (Razorpay, Cashfree, etc.)')
    actions.push('Request UPI transaction logs from NPCI for all identified UPI IDs')
  }
  actions.push('Freeze all identified bank accounts pending investigation under Section 102 CrPC / Section 106 BNS')
  actions.push('Request IMEI tracking and location history from telecom operators for identified devices')
  actions.push('Issue Look Out Circular (LOC) for kingpin suspects if identity confirmed')
  actions.push('Coordinate with cyber cell of respective state police for inter-state raids on identified addresses')
  lines.push('   ' + actions.map((a, i) => `${i + 1}. ${a}`).join('\n   '))
  lines.push('')

  lines.push('6. APPLICABLE LEGAL SECTIONS')
  lines.push('---------------------------')
  lines.push('   - Section 318(4) BNS: Cheating (fraudulent inducement)')
  lines.push('   - Section 319 BNS: Cheating by personation')
  lines.push('   - Section 111 BNS: Organized crime (if kingpin-mule hierarchy confirmed)')
  lines.push('   - Section 66-D IT Act 2000: Cheating by personation using computer resource')
  lines.push('   - Section 66-C IT Act 2000: Identity theft')
  if (patterns.some((p) => p.type === 'sim_swap')) {
    lines.push('   - Section 66-F IT Act 2000: Cyber terrorism (if SIM swap caused financial loss > Rs. 1 lakh)')
  }
  lines.push('')
  lines.push('--- End of Case Brief ---')
  lines.push(`Generated: ${new Date().toLocaleString('en-IN')}`)

  return lines.join('\n')
}

export function analyzeIntelligence(rawText: string): AnalysisResult {
  const entities = extractEntities(rawText)
  const relationships = extractRelationships(rawText, entities)
  const timeline = extractTimeline(rawText, entities)
  const patterns = detectFraudPatterns(rawText)
  const hierarchy = inferHierarchy(entities, relationships)
  const firBrief = generateFIRBrief(patterns, hierarchy, entities, relationships)

  return { entities, relationships, timeline, patterns, hierarchy, firBrief }
}

export const SAMPLE_INTELLIGENCE = `FIR No. 423/2023 — Jamtara SIM Swap Ring Investigation

On 15/06/2023, complainant Ramesh Kumar reported that his SBI account 9876543210 was drained of Rs. 2,50,000 after a SIM swap on his Airtel number 9876543210. The fraudsters intercepted OTPs and transferred funds via UPI to fraud@okhdfc.

Investigation revealed that the kingpin Aslam Khan operates from Jamtara, Jharkhand. Aslam Khan controls a network of mules including Suresh Paswan and Deepak Yadav. Suresh Paswan lent his bank account 45678901234 (HDFC Bank) to Aslam Khan on commission basis. Deepak Yadav received Rs. 50,000 from Aslam Khan for withdrawing cash from ATMs.

Aslam Khan called victim Ramesh Kumar on 14/06/2023 posing as Airtel customer service. The SIM swap was executed on 15/06/2023 at 10:30 AM. Immediately after, Rs. 2,50,000 was transferred from victim's account to fraud@okhdfc, then split: Rs. 1,50,000 sent to Suresh Paswan account 45678901234, and Rs. 1,00,000 sent to another UPI ID deepak@ybl.

Device IMEI 356789012345678 was used for the SIM swap. Aslam Khan uses phone number 8765432109. Suresh Paswan can be contacted at 7654321098. The address of Aslam Khan is Village Rampur, Jamtara, Jharkhand.

Victim Ramesh Kumar resides at Sector 12, Dwarka, New Delhi. His phone 9876543210 was compromised. He received a call from 8765432109 on 14/06/2023 at 6 PM.`
