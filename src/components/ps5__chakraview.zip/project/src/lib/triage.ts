export type CrimeType =
  | 'homicide'
  | 'sexual_assault'
  | 'burglary'
  | 'cyber_fraud'
  | 'arson'
  | 'drug_offense'
  | 'hit_and_run'
  | 'kidnapping'
  | 'robbery'
  | 'other'

export const CRIME_TYPES: { value: CrimeType; label: string }[] = [
  { value: 'homicide', label: 'Homicide' },
  { value: 'sexual_assault', label: 'Sexual Assault' },
  { value: 'burglary', label: 'Burglary' },
  { value: 'cyber_fraud', label: 'Cyber Fraud' },
  { value: 'arson', label: 'Arson' },
  { value: 'drug_offense', label: 'Drug Offense' },
  { value: 'hit_and_run', label: 'Hit and Run' },
  { value: 'kidnapping', label: 'Kidnapping' },
  { value: 'robbery', label: 'Robbery' },
  { value: 'other', label: 'Other' },
]

export type EvidenceCategory =
  | 'biological'
  | 'trace'
  | 'firearm'
  | 'digital'
  | 'document'
  | 'toolmark'
  | 'fingerprint'
  | 'footwear'
  | 'narcotic'
  | 'fire_accelerant'
  | 'weapon'
  | 'vehicle'
  | 'miscellaneous'

export const CATEGORY_META: Record<EvidenceCategory, { label: string; icon: string; color: string }> = {
  biological: { label: 'Biological', icon: '🧬', color: 'rose' },
  trace: { label: 'Trace', icon: '🔬', color: 'amber' },
  firearm: { label: 'Firearm', icon: '🔫', color: 'slate' },
  digital: { label: 'Digital', icon: '💻', color: 'sky' },
  document: { label: 'Document', icon: '📄', color: 'indigo' },
  toolmark: { label: 'Tool Mark', icon: '🔧', color: 'orange' },
  fingerprint: { label: 'Fingerprint', icon: '🖐️', color: 'cyan' },
  footwear: { label: 'Footwear', icon: '👞', color: 'lime' },
  narcotic: { label: 'Narcotic', icon: '💊', color: 'fuchsia' },
  fire_accelerant: { label: 'Fire Accelerant', icon: '🔥', color: 'red' },
  weapon: { label: 'Weapon', icon: '⚔️', color: 'zinc' },
  vehicle: { label: 'Vehicle', icon: '🚗', color: 'teal' },
  miscellaneous: { label: 'Miscellaneous', icon: '📦', color: 'gray' },
}

export type TriageResult = {
  category: EvidenceCategory
  priorityScore: number
  urgencyFlag: boolean
  recommendedTest: string
  rationale: string
  degradationHours: number | null
  integrityHash: string
}

const CATEGORY_KEYWORDS: Record<EvidenceCategory, string[]> = {
  biological: ['blood', 'semen', 'saliva', 'hair', 'tissue', 'dna', 'urine', 'sweat', 'skin', 'nail', 'tooth', 'bone', 'bodily fluid', 'vomit', 'menstrual', 'cigarette', 'butt'],
  trace: ['fiber', 'hair', 'glass', 'paint', 'soil', 'dust', 'pollen', 'gunshot residue', 'gsr', 'residue', 'fragment', 'shard', 'filament'],
  firearm: ['gun', 'pistol', 'revolver', 'rifle', 'shotgun', 'bullet', 'cartridge', 'casing', 'firearm', 'ammunition', 'magazine', 'projectile'],
  digital: ['phone', 'laptop', 'computer', 'hard drive', 'usb', 'sim card', 'tablet', 'camera', 'sd card', 'router', 'device', 'email', 'digital'],
  document: ['document', 'paper', 'letter', 'note', 'contract', 'receipt', 'id', 'passport', 'check', 'forgery', 'handwriting', 'signature', 'printed'],
  toolmark: ['tool', 'screwdriver', 'crowbar', 'hammer', 'pry bar', 'wrench', 'pliers', 'chisel', 'saw', 'cutting', 'toolmark', 'pry'],
  fingerprint: ['fingerprint', 'finger mark', 'latent print', 'print', 'smudge', 'touched surface', 'smooth surface'],
  footwear: ['shoe', 'boot', 'sandal', 'footwear', 'footprint', 'shoeprint', 'tire mark', 'tire', 'track'],
  narcotic: ['drug', 'narcotic', 'powder', 'pill', 'syringe', 'cannabis', 'heroin', 'cocaine', 'meth', 'opium', 'ganja', 'contraband', 'substance'],
  fire_accelerant: ['accelerant', 'gasoline', 'kerosene', 'petrol', 'fuel', 'lighter fluid', 'match', 'igniter', 'molotov', 'flammable', 'soot', 'char'],
  weapon: ['knife', 'blade', 'sword', 'bat', 'rod', 'pipe', 'rope', 'ligature', 'garrote', 'sharp object', 'blunt object', 'weapon', 'axe'],
  vehicle: ['vehicle', 'car', 'truck', 'motorcycle', 'bike', 'scooter', 'number plate', 'license plate', 'bumper', 'mirror', 'auto'],
  miscellaneous: [],
}

function classifyCategory(description: string): EvidenceCategory {
  const lower = description.toLowerCase()
  let bestCategory: EvidenceCategory = 'miscellaneous'
  let bestScore = 0

  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    let score = 0
    for (const kw of keywords) {
      if (lower.includes(kw)) score += kw.length > 4 ? 2 : 1
    }
    if (score > bestScore) {
      bestScore = score
      bestCategory = category as EvidenceCategory
    }
  }

  return bestCategory
}

const CATEGORY_BASE_PRIORITY: Record<EvidenceCategory, number> = {
  biological: 90,
  firearm: 85,
  digital: 80,
  fingerprint: 75,
  trace: 70,
  toolmark: 65,
  fire_accelerant: 82,
  narcotic: 72,
  footwear: 60,
  document: 55,
  weapon: 68,
  vehicle: 58,
  miscellaneous: 40,
}

const CRIME_RELEVANCE: Record<CrimeType, Partial<Record<EvidenceCategory, number>>> = {
  homicide: {
    biological: 20, firearm: 18, weapon: 15, trace: 12, fingerprint: 10,
    toolmark: 10, footwear: 8, digital: 8, document: 5, vehicle: 6,
  },
  sexual_assault: {
    biological: 22, trace: 15, fingerprint: 12, footwear: 8, digital: 10,
    document: 5, weapon: 8,
  },
  burglary: {
    toolmark: 18, fingerprint: 16, footwear: 14, trace: 10, digital: 8,
    document: 6, biological: 5, vehicle: 8,
  },
  cyber_fraud: {
    digital: 25, document: 18, fingerprint: 8, miscellaneous: 5,
    biological: 2, trace: 3,
  },
  arson: {
    fire_accelerant: 25, trace: 12, digital: 8, document: 6, miscellaneous: 5,
    biological: 5,
  },
  drug_offense: {
    narcotic: 25, digital: 15, document: 12, fingerprint: 8, trace: 6,
    miscellaneous: 5, biological: 5,
  },
  hit_and_run: {
    vehicle: 22, biological: 15, trace: 12, footwear: 8,
  },
  kidnapping: {
    digital: 18, document: 15, fingerprint: 12, footwear: 10, trace: 8,
    biological: 8, vehicle: 10,
  },
  robbery: {
    weapon: 16, firearm: 15, fingerprint: 12, footwear: 10, digital: 10,
    trace: 8, document: 6, biological: 5,
  },
  other: {
    digital: 10, document: 10, fingerprint: 8, trace: 8, biological: 8,
  },
}

const RECOMMENDED_TESTS: Record<EvidenceCategory, string> = {
  biological: 'DNA profiling + serology (PCR, STR analysis)',
  trace: 'Microscopy + chromatography (GC-MS, FTIR)',
  firearm: 'Ballistics comparison + NIBIN entry + GSR analysis',
  digital: 'Digital forensics extraction (mobile/computer imaging, hash verification)',
  document: 'Questioned document examination (handwriting, ink, paper analysis)',
  toolmark: 'Toolmark comparison casting + microscopy',
  fingerprint: 'Latent print development (cyanoacrylate, powder, AFIS search)',
  footwear: 'Footwear/tire impression casting + database comparison',
  narcotic: 'Chemical identification (color test, GC-MS, FTIR)',
  fire_accelerant: 'Ignitable liquid residue analysis (GC-MS headspace)',
  weapon: 'Trace evidence + DNA swab + fingerprint processing',
  vehicle: 'VIN recovery + paint transfer analysis + biological swab',
  miscellaneous: 'General forensic screening + photography',
}

const DEGRADATION_HOURS: Partial<Record<EvidenceCategory, number>> = {
  biological: 48,
  trace: 72,
  fire_accelerant: 24,
  fingerprint: 168,
}

function computeHash(input: string): string {
  let hash = 0
  for (let i = 0; i < input.length; i++) {
    const char = input.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash
  }
  const hex = (hash >>> 0).toString(16).padStart(8, '0')
  return `EV-${hex}-${Date.now().toString(36).slice(-4).toUpperCase()}`
}

function buildRationale(
  category: EvidenceCategory,
  crimeType: CrimeType,
  score: number,
  urgency: boolean,
): string {
  const catLabel = CATEGORY_META[category].label
  const parts: string[] = []

  parts.push(`Classified as ${catLabel.toLowerCase()} evidence based on item description keywords.`)

  const relevance = CRIME_RELEVANCE[crimeType]?.[category]
  if (relevance && relevance > 0) {
    parts.push(`High probative value for ${crimeType.replace('_', ' ')} cases — directly linked to establishing identity, linkage, or modus operandi.`)
  } else if (relevance && relevance <= 8) {
    parts.push(`Moderate relevance to ${crimeType.replace('_', ' ')} — may provide circumstantial corroboration.`)
  } else {
    parts.push(`Limited direct relevance to ${crimeType.replace('_', ' ')} but retained for completeness.`)
  }

  if (urgency) {
    parts.push('Flagged URGENT: biological/degradable evidence at risk of degradation — requires immediate collection and preservation to prevent loss of DNA or volatile trace material.')
  }

  if (score >= 85) {
    parts.push('Priority score reflects high likelihood of yielding identifiable, case-critical results.')
  } else if (score >= 60) {
    parts.push('Priority score reflects moderate evidentiary value worth testing within standard FSL turnaround.')
  } else {
    parts.push('Priority score reflects lower probative value — batch with routine screening.')
  }

  return parts.join(' ')
}

function shouldFlagUrgent(category: EvidenceCategory, description: string): boolean {
  const urgentCategories: EvidenceCategory[] = ['biological', 'fire_accelerant', 'trace']
  const degradationKeywords = ['blood', 'semen', 'saliva', 'wet', 'fresh', 'decomposing', 'volatile', 'biological']
  const lower = description.toLowerCase()
  return (
    urgentCategories.includes(category) &&
    (category === 'biological' || degradationKeywords.some((k) => lower.includes(k)))
  )
}

export function triageItem(
  description: string,
  crimeType: CrimeType,
  quantity: number = 1,
): TriageResult {
  const category = classifyCategory(description)
  const basePriority = CATEGORY_BASE_PRIORITY[category]
  const crimeRelevance = CRIME_RELEVANCE[crimeType]?.[category] ?? 5
  const quantityAdjust = quantity > 1 ? Math.min(quantity * 2, 8) : 0
  const score = Math.min(100, Math.round(basePriority + crimeRelevance + quantityAdjust))
  const urgency = shouldFlagUrgent(category, description)
  const recommendedTest = RECOMMENDED_TESTS[category]
  const degradationHours = DEGRADATION_HOURS[category] ?? null
  const rationale = buildRationale(category, crimeType, score, urgency)
  const integrityHash = computeHash(`${description}|${category}|${score}|${Date.now()}`)

  return { category, priorityScore: score, urgencyFlag: urgency, recommendedTest, rationale, degradationHours, integrityHash }
}

export function rankItems<T extends { triage: TriageResult }>(items: T[]): T[] {
  return [...items].sort((a, b) => {
    if (a.triage.urgencyFlag !== b.triage.urgencyFlag) return a.triage.urgencyFlag ? -1 : 1
    return b.triage.priorityScore - a.triage.priorityScore
  })
}

export function getPriorityLabel(score: number): { label: string; color: string } {
  if (score >= 85) return { label: 'Critical', color: 'rose' }
  if (score >= 70) return { label: 'High', color: 'amber' }
  if (score >= 55) return { label: 'Medium', color: 'sky' }
  return { label: 'Low', color: 'slate' }
}

export function computeCustodyHash(
  evidenceId: string,
  action: string,
  handler: string,
  previousHash: string | null,
): string {
  return computeHash(`${evidenceId}|${action}|${handler}|${previousHash || 'GENESIS'}|${Date.now()}`)
}

export type LinkageMatch = {
  otherCaseId: string
  otherCaseTitle: string
  otherCaseType: string
  evidenceId: string
  evidenceDescription: string
  matchScore: number
  linkType: string
  rationale: string
}

export function detectCrossCaseLinkages(
  currentItems: { id: string; description: string; category: string; case_id: string }[],
  otherCases: { id: string; title: string; crime_type: string }[],
  otherItems: { id: string; description: string; category: string; case_id: string }[],
): LinkageMatch[] {
  const matches: LinkageMatch[] = []

  for (const curr of currentItems) {
    for (const other of otherItems) {
      if (curr.case_id === other.case_id) continue
      const caseInfo = otherCases.find((c) => c.id === other.case_id)
      if (!caseInfo) continue

      let score = 0
      let linkType = ''
      let rationale = ''

      if (curr.category === other.category && curr.category !== 'miscellaneous') {
        score += 40
        const currWords = new Set(curr.description.toLowerCase().split(/\s+/).filter((w) => w.length > 3))
        const otherWords = new Set(other.description.toLowerCase().split(/\s+/).filter((w) => w.length > 3))
        const shared = [...currWords].filter((w) => otherWords.has(w))
        if (shared.length >= 2) {
          score += shared.length * 10
          linkType = 'Pattern Match'
          rationale = `Same evidence category (${curr.category}) and ${shared.length} shared keywords: "${shared.slice(0, 4).join('", "')}" — possible serial offender linkage.`
        } else if (shared.length === 1) {
          score += 8
          linkType = 'Category Match'
          rationale = `Same evidence category (${curr.category}) with partial description overlap — worth cross-referencing.`
        } else {
          linkType = 'Category Match'
          rationale = `Same evidence category (${curr.category}) — review for potential linkage.`
        }
      }

      if (score >= 50) {
        matches.push({
          otherCaseId: caseInfo.id,
          otherCaseTitle: caseInfo.title,
          otherCaseType: caseInfo.crime_type,
          evidenceId: other.id,
          evidenceDescription: other.description,
          matchScore: Math.min(100, score),
          linkType,
          rationale,
        })
      }
    }
  }

  return matches.sort((a, b) => b.matchScore - a.matchScore)
}

export function formatTimeRemaining(deadline: string | null): string {
  if (!deadline) return 'No degradation risk'
  const now = Date.now()
  const dl = new Date(deadline).getTime()
  const diff = dl - now
  if (diff <= 0) return 'DEGRADED — past golden hour'
  const hours = Math.floor(diff / (1000 * 60 * 60))
  const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
  if (hours >= 24) {
    const days = Math.floor(hours / 24)
    return `${days}d ${hours % 24}h remaining`
  }
  return `${hours}h ${mins}m remaining`
}

export function getDegradationUrgency(deadline: string | null): 'critical' | 'warning' | 'safe' | 'none' {
  if (!deadline) return 'none'
  const diff = new Date(deadline).getTime() - Date.now()
  if (diff <= 0) return 'critical'
  if (diff < 6 * 60 * 60 * 1000) return 'critical'
  if (diff < 24 * 60 * 60 * 1000) return 'warning'
  return 'safe'
}
