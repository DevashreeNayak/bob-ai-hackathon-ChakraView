import { useState, useEffect, useCallback } from 'react'
import {
  Shield, Search, ChevronRight, RotateCcw, Download, AlertTriangle,
  Network, Users, GitBranch, Clock, FileText, Zap, XCircle,
  TrendingUp, Phone, Smartphone, User,
  Crown, Footprints, Target, Activity, Copy, CheckCircle2, Sparkles,
} from 'lucide-react'
import { supabase, type FraudCase, type Entity, type Relationship, type TimelineEvent as DBTimelineEvent } from './lib/supabase'
import {
  analyzeIntelligence, ENTITY_META, REL_META, SAMPLE_INTELLIGENCE,
  type EntityType, type RelationshipType, type AnalysisResult,
} from './lib/fraud'
import NetworkGraph, { type GraphNode, type GraphEdge } from './NetworkGraph'

type Step = 'setup' | 'input' | 'results'
type ResultsTab = 'network' | 'entities' | 'flow' | 'timeline' | 'fir'

export default function App() {
  const [step, setStep] = useState<Step>('setup')
  const [caseData, setCaseData] = useState<FraudCase | null>(null)
  const [caseForm, setCaseForm] = useState({ title: '', officer: '', jurisdiction: '' })
  const [rawIntel, setRawIntel] = useState('')
  const [analyzing, setAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null)
  const [savedEntities, setSavedEntities] = useState<Entity[]>([])
  const [savedRelationships, setSavedRelationships] = useState<Relationship[]>([])
  const [savedTimeline, setSavedTimeline] = useState<DBTimelineEvent[]>([])
  const [activeTab, setActiveTab] = useState<ResultsTab>('network')
  const [selectedNode, setSelectedNode] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const createCase = async () => {
    if (!caseForm.title.trim()) { setError('Please enter a case title.'); return }
    setError(null)
    setLoading(true)
    const { data, error: dbError } = await supabase.from('fraud_cases').insert({
      title: caseForm.title.trim(),
      officer_name: caseForm.officer.trim() || null,
      jurisdiction: caseForm.jurisdiction.trim() || null,
      status: 'intake',
    }).select().single()
    setLoading(false)
    if (dbError || !data) { setError('Could not create the case.'); return }
    setCaseData(data)
    setStep('input')
  }

  const runAnalysis = async () => {
    if (!caseData || !rawIntel.trim()) return
    setAnalyzing(true)
    setError(null)

    const result = analyzeIntelligence(rawIntel.trim())
    setAnalysis(result)

    const { error: caseErr } = await supabase.from('fraud_cases').update({
      raw_intelligence: rawIntel.trim(),
      fir_brief: result.firBrief,
      status: 'analyzed',
    }).eq('id', caseData.id)

    if (caseErr) { setAnalyzing(false); setError('Failed to save case data.'); return }

    const entityRows = result.entities.map((e) => ({
      case_id: caseData.id,
      entity_type: e.type,
      label: e.label,
      risk_score: e.riskScore,
      role: e.role || null,
      metadata: e.metadata || {},
    }))
    const { data: insertedEntities, error: entErr } = await supabase.from('entities').insert(entityRows).select()
    if (entErr) { setAnalyzing(false); setError('Failed to save entities.'); return }

    const labelToId = new Map<string, string>()
    insertedEntities.forEach((e: Entity) => labelToId.set(e.label, e.id))

    const relRows = result.relationships.map((r) => {
      const sourceId = labelToId.get(r.sourceLabel)
      const targetId = labelToId.get(r.targetLabel)
      if (!sourceId || !targetId) return null
      return {
        case_id: caseData.id,
        source_entity_id: sourceId,
        target_entity_id: targetId,
        rel_type: r.type,
        amount: r.amount || null,
        transaction_count: r.transactionCount || null,
      }
    }).filter(Boolean)

    if (relRows.length > 0) {
      await supabase.from('relationships').insert(relRows as any[])
    }

    const timelineRows = result.timeline.map((t) => ({
      case_id: caseData.id,
      event_type: t.eventType,
      description: t.description,
      event_date: t.date || null,
      entity_ids: t.entityLabels.map((l) => labelToId.get(l)).filter(Boolean) as string[],
    }))
    if (timelineRows.length > 0) {
      await supabase.from('timeline_events').insert(timelineRows)
    }

    await loadData(caseData.id)
    setAnalyzing(false)
    setStep('results')
  }

  const loadData = useCallback(async (caseId: string) => {
    const { data: ents } = await supabase.from('entities').select('*').eq('case_id', caseId)
    setSavedEntities(ents || [])
    const { data: rels } = await supabase.from('relationships').select('*').eq('case_id', caseId)
    setSavedRelationships(rels || [])
    const { data: tl } = await supabase.from('timeline_events').select('*').eq('case_id', caseId).order('event_date', { ascending: true, nullsFirst: false })
    setSavedTimeline(tl || [])
  }, [])

  const resetAll = async () => {
    if (caseData) await supabase.from('fraud_cases').delete().eq('id', caseData.id)
    setCaseData(null)
    setAnalysis(null)
    setSavedEntities([])
    setSavedRelationships([])
    setSavedTimeline([])
    setRawIntel('')
    setCaseForm({ title: '', officer: '', jurisdiction: '' })
    setSelectedNode(null)
    setActiveTab('network')
    setStep('setup')
  }

  const exportFIR = () => {
    if (!analysis || !caseData) return
    const blob = new Blob([analysis.firBrief], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `FIR-brief-${caseData.title.replace(/\s+/g, '-').toLowerCase()}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  const copyFIR = () => {
    if (!analysis) return
    navigator.clipboard.writeText(analysis.firBrief)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const loadSample = () => setRawIntel(SAMPLE_INTELLIGENCE)

  useEffect(() => {
    if (caseData) loadData(caseData.id)
  }, [caseData, loadData])

  const graphNodes: GraphNode[] = savedEntities.map((e) => ({
    id: e.id,
    label: e.label,
    type: e.entity_type as EntityType,
    riskScore: e.risk_score || 0,
    role: e.role || '',
    x: 400 + (Math.random() - 0.5) * 300,
    y: 250 + (Math.random() - 0.5) * 200,
    vx: 0,
    vy: 0,
  }))

  const graphEdges: GraphEdge[] = savedRelationships.map((r) => ({
    source: r.source_entity_id,
    target: r.target_entity_id,
    type: r.rel_type as RelationshipType,
    amount: r.amount || undefined,
  }))

  return (
    <div className="min-h-screen bg-[#0a1628]">
      <Header step={step} onReset={resetAll} />

      <main className="max-w-6xl mx-auto px-4 sm:px-6 pb-24">
        {error && (
          <div className="mb-6 p-4 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-200 text-sm flex items-center gap-2 animate-fade-in">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            {error}
            <button onClick={() => setError(null)} className="ml-auto text-rose-300 hover:text-rose-100"><XCircle className="w-4 h-4" /></button>
          </div>
        )}

        {step === 'setup' && (
          <SetupStep form={caseForm} setForm={setCaseForm} onCreate={createCase} loading={loading} />
        )}

        {step === 'input' && caseData && (
          <InputStep
            caseData={caseData}
            rawIntel={rawIntel}
            setRawIntel={setRawIntel}
            onAnalyze={runAnalysis}
            onBack={() => setStep('setup')}
            onLoadSample={loadSample}
            analyzing={analyzing}
          />
        )}

        {step === 'results' && caseData && analysis && (
          <ResultsStep
            caseData={caseData}
            analysis={analysis}
            entities={savedEntities}
            relationships={savedRelationships}
            timeline={savedTimeline}
            graphNodes={graphNodes}
            graphEdges={graphEdges}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            selectedNode={selectedNode}
            setSelectedNode={setSelectedNode}
            onExport={exportFIR}
            onCopy={copyFIR}
            copied={copied}
            onReset={resetAll}
          />
        )}
      </main>
    </div>
  )
}

function Header({ step, onReset }: { step: Step; onReset: () => void }) {
  const steps: { key: Step; label: string; icon: typeof Shield }[] = [
    { key: 'setup', label: 'Case Setup', icon: Shield },
    { key: 'input', label: 'Intelligence', icon: Search },
    { key: 'results', label: 'Analysis', icon: Network },
  ]
  const currentIndex = steps.findIndex((s) => s.key === step)

  return (
    <header className="sticky top-0 z-50 bg-[#0a1628]/90 backdrop-blur-md border-b border-[#1e4064]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-rose-500 to-orange-700 flex items-center justify-center shadow-lg shadow-rose-500/20">
              <Network className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-base font-bold text-white leading-tight">Cyber Fraud Network Analyzer</h1>
              <p className="text-xs text-[#6b8299] leading-tight">Entity Extraction · Pattern Detection · FIR Brief Generator</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-1">
            {steps.map((s, i) => {
              const Icon = s.icon
              const active = i === currentIndex
              const done = i < currentIndex
              return (
                <div key={s.key} className="flex items-center">
                  <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${active ? 'text-rose-300 bg-rose-500/10' : done ? 'text-[#6b8299]' : 'text-[#4a6076]'}`}>
                    <Icon className="w-4 h-4" />
                    {s.label}
                  </div>
                  {i < steps.length - 1 && <ChevronRight className="w-3 h-3 text-[#2a5078] mx-0.5" />}
                </div>
              )
            })}
          </div>
          {step !== 'setup' && (
            <button onClick={onReset} className="btn-ghost text-sm flex items-center gap-1.5">
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">New Case</span>
            </button>
          )}
        </div>
      </div>
    </header>
  )
}

function SetupStep({
  form, setForm, onCreate, loading,
}: {
  form: any
  setForm: (f: any) => void
  onCreate: () => void
  loading: boolean
}) {
  return (
    <div className="animate-fade-in max-w-2xl mx-auto pt-8">
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs font-medium mb-4">
          <Network className="w-3.5 h-3.5" />
          IBM Bob AI Hackathon · NFSU · Track 2 · Problem 05
        </div>
        <h2 className="text-3xl font-bold text-white mb-3">Cyber Fraud Network Analyzer</h2>
        <p className="text-[#9bb3c9] text-base max-w-xl mx-auto">
          Feed in unstructured cyber fraud intelligence — transaction records, call logs, device IDs, accused names. The system extracts entities, maps relationships, identifies the fraud pattern, and generates an FIR-ready case brief.
        </p>
      </div>

      <div className="card p-6 sm:p-8 space-y-5">
        <div>
          <label className="block text-sm font-semibold text-white mb-2">Case Title <span className="text-rose-400">*</span></label>
          <input className="input" placeholder="e.g., Jamtara SIM Swap Ring — FIR 423/2023"
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            onKeyDown={(e) => e.key === 'Enter' && onCreate()} />
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-white mb-2">Investigating Officer</label>
            <input className="input" placeholder="e.g., Insp. Verma, Cyber Cell"
              value={form.officer}
              onChange={(e) => setForm({ ...form, officer: e.target.value })} />
          </div>
          <div>
            <label className="block text-sm font-semibold text-white mb-2">Jurisdiction</label>
            <input className="input" placeholder="e.g., Jamtara, Jharkhand"
              value={form.jurisdiction}
              onChange={(e) => setForm({ ...form, jurisdiction: e.target.value })} />
          </div>
        </div>
        <button onClick={onCreate} disabled={loading || !form.title.trim()} className="btn-primary w-full flex items-center justify-center gap-2">
          {loading ? (
            <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Creating case...</>
          ) : (
            <>Create Case & Input Intelligence <ChevronRight className="w-4 h-4" /></>
          )}
        </button>
      </div>

      <div className="mt-6 p-4 rounded-lg bg-[#0f2942]/50 border border-[#1e4064] text-sm text-[#9bb3c9]">
        <p className="flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <span><strong className="text-white">Real case reference:</strong> Jamtara SIM-swap ring (Jharkhand) — 95,000+ UPI fraud cases in FY2023. Investigators manually traced connections between bank accounts, SIM cards, and devices over weeks. Most cases went unsolved due to lack of network visualization tools.</span>
        </p>
      </div>
    </div>
  )
}

function InputStep({
  rawIntel, setRawIntel, onAnalyze, onBack, onLoadSample, analyzing,
}: {
  rawIntel: string
  setRawIntel: (s: string) => void
  onAnalyze: () => void
  onBack: () => void
  onLoadSample: () => void
  analyzing: boolean
}) {
  const wordCount = rawIntel.trim().split(/\s+/).filter(Boolean).length
  return (
    <div className="animate-fade-in pt-6 max-w-4xl mx-auto">
      <div className="card p-6 sm:p-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-white">Raw Intelligence Input</h3>
            <p className="text-sm text-[#6b8299] mt-1">Paste unstructured case intelligence — FIR excerpts, call records, transaction logs, suspect statements.</p>
          </div>
          <button onClick={onLoadSample} className="btn-ghost text-sm flex items-center gap-1.5 shrink-0">
            <Sparkles className="w-3.5 h-3.5" /> Load Sample
          </button>
        </div>

        <textarea
          className="input min-h-[320px] resize-y font-mono text-sm leading-relaxed"
          placeholder={`Paste intelligence here...\n\nInclude:\n- Accused and victim names\n- Phone numbers, bank account numbers, UPI IDs\n- Transaction amounts and dates\n- Call logs and SIM swap details\n- Device IMEI numbers\n- Addresses and locations\n\nOr click "Load Sample" to see a real Jamtara SIM swap case.`}
          value={rawIntel}
          onChange={(e) => setRawIntel(e.target.value)}
        />

        <div className="flex items-center justify-between mt-4">
          <span className="text-xs text-[#6b8299]">{wordCount} words · {rawIntel.length} characters</span>
          <div className="flex gap-3">
            <button onClick={onBack} className="btn-ghost flex items-center gap-2">
              <RotateCcw className="w-4 h-4" /> Edit Case
            </button>
            <button onClick={onAnalyze} disabled={analyzing || !rawIntel.trim()}
              className="btn-primary flex items-center justify-center gap-2 px-6">
              {analyzing ? (
                <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Extracting entities...</>
              ) : (
                <><Zap className="w-4 h-4" /> Analyze Intelligence</>
              )}
            </button>
          </div>
        </div>
      </div>

      <div className="mt-4 grid sm:grid-cols-3 gap-3">
        <FeatureHint icon={Search} title="Entity Extraction" desc="Auto-detects persons, accounts, phones, UPI IDs, IMEI, addresses" />
        <FeatureHint icon={GitBranch} title="Hierarchy Inference" desc="Maps kingpin → mule → victim relationships automatically" />
        <FeatureHint icon={FileText} title="FIR Brief Generator" desc="Outputs a court-ready case brief with legal sections" />
      </div>
    </div>
  )
}

function FeatureHint({ icon: Icon, title, desc }: { icon: typeof Shield; title: string; desc: string }) {
  return (
    <div className="card p-4">
      <Icon className="w-5 h-5 text-rose-400 mb-2" />
      <h4 className="text-sm font-semibold text-white">{title}</h4>
      <p className="text-xs text-[#6b8299] mt-1">{desc}</p>
    </div>
  )
}

function ResultsStep({
  caseData, analysis, entities, relationships, timeline, graphNodes, graphEdges,
  activeTab, setActiveTab, selectedNode, setSelectedNode, onExport, onCopy, copied, onReset,
}: {
  caseData: FraudCase
  analysis: AnalysisResult
  entities: Entity[]
  relationships: Relationship[]
  timeline: DBTimelineEvent[]
  graphNodes: GraphNode[]
  graphEdges: GraphEdge[]
  activeTab: ResultsTab
  setActiveTab: (t: ResultsTab) => void
  selectedNode: string | null
  setSelectedNode: (id: string | null) => void
  onExport: () => void
  onCopy: () => void
  copied: boolean
  onReset: () => void
}) {
  const topPattern = analysis.patterns[0]
  const totalAmount = relationships.filter((r) => r.amount).reduce((s, r) => s + (r.amount || 0), 0)

  const tabs: { key: ResultsTab; label: string; icon: typeof Shield; badge?: number }[] = [
    { key: 'network', label: 'Network Graph', icon: Network },
    { key: 'entities', label: 'Entity Registry', icon: Users, badge: entities.length },
    { key: 'flow', label: 'Financial Flow', icon: TrendingUp, badge: relationships.filter((r) => r.rel_type === 'transfers_to').length },
    { key: 'timeline', label: 'Timeline', icon: Clock, badge: timeline.length },
    { key: 'fir', label: 'FIR Case Brief', icon: FileText },
  ]

  return (
    <div className="animate-fade-in pt-6 space-y-6">
      <div className="card p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Investigation Dashboard</h2>
            <p className="text-sm text-[#9bb3c9]">
              {caseData.title}
              {caseData.jurisdiction && ` · ${caseData.jurisdiction}`}
              {' · '}{new Date(caseData.created_at).toLocaleDateString('en-IN')}
            </p>
          </div>
          {activeTab === 'fir' && (
            <div className="flex gap-2">
              <button onClick={onCopy} className="btn-ghost text-sm flex items-center gap-1.5">
                {copied ? <><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Copied</> : <><Copy className="w-3.5 h-3.5" /> Copy</>}
              </button>
              <button onClick={onExport} className="btn-primary text-sm flex items-center gap-1.5">
                <Download className="w-4 h-4" /> Download
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatCard label="Entities Extracted" value={entities.length} icon={Users} color="cyan" />
          <StatCard label="Relationships Mapped" value={relationships.length} icon={GitBranch} color="rose" />
          <StatCard label="Fraud Pattern" value={topPattern ? topPattern.confidence : 0} suffix="%" icon={Zap} color="amber" />
          <StatCard label="Traced Amount" value={totalAmount} prefix="₹" icon={TrendingUp} color="emerald" />
        </div>

        {topPattern && (
          <div className="mt-4 p-4 rounded-lg bg-rose-500/10 border border-rose-500/30">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-rose-500/20 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <p className="text-sm font-semibold text-rose-300">{topPattern.label} detected with {topPattern.confidence}% confidence</p>
                <p className="text-xs text-rose-200/70 mt-0.5">{topPattern.description}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        {tabs.map((tab) => {
          const Icon = tab.icon
          const active = activeTab === tab.key
          return (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                active ? 'bg-rose-500/15 text-rose-300 border border-rose-500/40' : 'bg-[#0f2942] text-[#9bb3c9] border border-[#1e4064] hover:border-[#2a5078]'
              }`}>
              <Icon className="w-4 h-4" />
              {tab.label}
              {tab.badge !== undefined && tab.badge > 0 && (
                <span className="ml-1 px-1.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold">{tab.badge}</span>
              )}
            </button>
          )
        })}
      </div>

      {activeTab === 'network' && (
        <NetworkTab nodes={graphNodes} edges={graphEdges} selectedNode={selectedNode} setSelectedNode={setSelectedNode} />
      )}
      {activeTab === 'entities' && <EntitiesTab entities={entities} />}
      {activeTab === 'flow' && <FlowTab relationships={relationships} entities={entities} />}
      {activeTab === 'timeline' && <TimelineTab events={timeline} />}
      {activeTab === 'fir' && <FIRTab brief={analysis.firBrief} />}

      <div className="flex justify-center pt-2">
        <button onClick={onReset} className="btn-ghost flex items-center gap-2">
          <RotateCcw className="w-4 h-4" /> Start New Case
        </button>
      </div>
    </div>
  )
}

function NetworkTab({
  nodes, edges, selectedNode, setSelectedNode,
}: {
  nodes: GraphNode[]
  edges: GraphEdge[]
  selectedNode: string | null
  setSelectedNode: (id: string | null) => void
}) {
  return (
    <div className="space-y-4">
      <div className="card p-6">
        <h3 className="text-lg font-bold text-white mb-1">Interactive Fraud Network Graph</h3>
        <p className="text-sm text-[#6b8299] mb-4">Force-directed visualization of all extracted entities and their relationships. Drag nodes to reposition. Hover for details. Click to select.</p>

        <div className="relative w-full h-[500px] rounded-lg bg-[#0a1628] border border-[#1e4064] overflow-hidden">
          {nodes.length === 0 ? (
            <div className="flex items-center justify-center h-full text-[#6b8299]">
              <div className="text-center"><Network className="w-8 h-8 mx-auto mb-3 opacity-40" /><p className="text-sm">No entities to display.</p></div>
            </div>
          ) : (
            <NetworkGraph nodes={nodes} edges={edges} onNodeClick={(n) => setSelectedNode(n.id)} selectedNode={selectedNode} />
          )}
        </div>

        <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <LegendItem color="#f43f5e" label="Kingpin" icon={Crown} />
          <LegendItem color="#fbbf24" label="Mule" icon={Footprints} />
          <LegendItem color="#34d399" label="Victim" icon={Target} />
          <LegendItem color="#2a5078" label="Unassigned" icon={User} />
        </div>
      </div>

      <div className="card p-5">
        <h4 className="text-sm font-semibold text-white mb-3">Relationship Types</h4>
        <div className="flex flex-wrap gap-3">
          {Object.entries(REL_META).map(([key, meta]) => (
            <div key={key} className="flex items-center gap-2">
              <div className={`w-8 h-px ${meta.dashed ? 'border-t-2 border-dashed' : ''}`} style={{ borderColor: meta.color, backgroundColor: meta.dashed ? 'transparent' : meta.color }} />
              <span className="text-xs text-[#9bb3c9]">{meta.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function LegendItem({ color, label, icon: Icon }: { color: string; label: string; icon: typeof Shield }) {
  return (
    <div className="flex items-center gap-2">
      <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ backgroundColor: `${color}20`, border: `2px solid ${color}` }}>
        <Icon className="w-3 h-3" style={{ color }} />
      </div>
      <span className="text-xs text-[#9bb3c9]">{label}</span>
    </div>
  )
}

function EntitiesTab({ entities }: { entities: Entity[] }) {
  const [filter, setFilter] = useState<string>('all')
  const types = ['all', ...new Set(entities.map((e) => e.entity_type))]
  const filtered = filter === 'all' ? entities : entities.filter((e) => e.entity_type === filter)

  const sorted = [...filtered].sort((a, b) => (b.risk_score || 0) - (a.risk_score || 0))

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-white">Entity Registry</h3>
          <select className="select max-w-[200px]" value={filter} onChange={(e) => setFilter(e.target.value)}>
            {types.map((t) => (
              <option key={t} value={t}>{t === 'all' ? 'All Types' : ENTITY_META[t as EntityType]?.label || t}</option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          {sorted.map((e) => {
            const meta = ENTITY_META[e.entity_type as EntityType] || ENTITY_META.person
            const riskColor = (e.risk_score || 0) >= 75 ? 'rose' : (e.risk_score || 0) >= 50 ? 'amber' : 'sky'
            return (
              <div key={e.id} className="flex items-center gap-3 p-3 rounded-lg bg-[#0a1628] border border-[#1e4064] hover:border-[#2a5078] transition-all animate-slide-in">
                <span className="text-xl shrink-0">{meta.icon}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">{e.label}</p>
                  <p className="text-xs text-[#6b8299]">{meta.label}{e.role && ` · ${e.role}`}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <div className="w-16 h-1.5 rounded-full bg-[#14365a] overflow-hidden">
                    <div className={`h-full bg-${riskColor}-500`} style={{ width: `${e.risk_score || 0}%` }} />
                  </div>
                  <span className={`text-sm font-bold text-${riskColor}-300 w-8 text-right`}>{e.risk_score || 0}</span>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function FlowTab({ relationships, entities }: { relationships: Relationship[]; entities: Entity[] }) {
  const transfers = relationships.filter((r) => r.rel_type === 'transfers_to')
  const totalAmount = transfers.reduce((s, r) => s + (r.amount || 0), 0)

  const getLabel = (id: string) => entities.find((e) => e.id === id)?.label || 'Unknown'

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <h3 className="text-lg font-bold text-white mb-1">Financial Flow Analysis</h3>
        <p className="text-sm text-[#6b8299] mb-4">Traced money movement between entities. Total traced amount: <span className="text-emerald-300 font-bold">₹{totalAmount.toLocaleString('en-IN')}</span></p>

        {transfers.length === 0 ? (
          <div className="text-center py-8 text-[#6b8299]">
            <TrendingUp className="w-8 h-8 mx-auto mb-3 opacity-40" />
            <p className="text-sm">No financial flows extracted from the intelligence.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {transfers.map((t, i) => (
              <div key={t.id} className="flex items-center gap-4 p-4 rounded-lg bg-[#0a1628] border border-[#1e4064] animate-slide-in" style={{ animationDelay: `${i * 40}ms` }}>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium text-white">{getLabel(t.source_entity_id)}</span>
                    <ChevronRight className="w-3 h-3 text-rose-400" />
                    <span className="text-sm font-medium text-white">{getLabel(t.target_entity_id)}</span>
                  </div>
                  <p className="text-xs text-[#6b8299]">{REL_META[t.rel_type as RelationshipType]?.label || t.rel_type}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-lg font-bold text-emerald-300">₹{(t.amount || 0).toLocaleString('en-IN')}</p>
                  <p className="text-xs text-[#6b8299]">{t.transaction_count || 1} transaction(s)</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="card p-5">
        <h4 className="text-sm font-semibold text-white mb-3">All Relationships</h4>
        <div className="space-y-2">
          {relationships.map((r) => {
            const meta = REL_META[r.rel_type as RelationshipType] || REL_META.linked_to
            return (
              <div key={r.id} className="flex items-center gap-2 p-2 rounded-lg bg-[#0a1628] border border-[#1e4064] text-sm">
                <span className="text-white font-medium">{getLabel(r.source_entity_id)}</span>
                <span className="text-xs px-2 py-0.5 rounded" style={{ color: meta.color, backgroundColor: `${meta.color}15` }}>{meta.label}</span>
                <span className="text-white font-medium">{getLabel(r.target_entity_id)}</span>
                {r.amount && <span className="text-emerald-300 text-xs ml-auto">₹{r.amount.toLocaleString('en-IN')}</span>}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function TimelineTab({ events }: { events: DBTimelineEvent[] }) {
  const eventIcons: Record<string, typeof Shield> = {
    transaction: TrendingUp, sim_swap: Smartphone, call: Phone, event: Activity,
  }
  return (
    <div className="card p-5">
      <h3 className="text-lg font-bold text-white mb-1">Investigation Timeline</h3>
      <p className="text-sm text-[#6b8299] mb-4">Chronological reconstruction of events extracted from intelligence.</p>

      {events.length === 0 ? (
        <div className="text-center py-8 text-[#6b8299]">
          <Clock className="w-8 h-8 mx-auto mb-3 opacity-40" />
          <p className="text-sm">No timeline events extracted.</p>
        </div>
      ) : (
        <div className="relative pl-6">
          <div className="absolute left-2 top-0 bottom-0 w-px bg-[#1e4064]" />
          {events.map((e, i) => {
            const Icon = eventIcons[e.event_type] || Activity
            return (
              <div key={e.id} className="relative mb-4 last:mb-0 animate-slide-in" style={{ animationDelay: `${i * 40}ms` }}>
                <div className="absolute -left-[18px] top-1 w-3 h-3 rounded-full bg-rose-500 border-2 border-[#0a1628]" />
                <div className="p-3 rounded-lg bg-[#0a1628] border border-[#1e4064]">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-sm font-semibold text-white flex items-center gap-1.5">
                      <Icon className="w-3.5 h-3.5 text-rose-400" />
                      {e.event_type.replace('_', ' ').replace(/\b\w/g, (c) => c.toUpperCase())}
                    </span>
                    {e.event_date && <span className="text-xs text-[#6b8299]">{new Date(e.event_date).toLocaleDateString('en-IN')}</span>}
                  </div>
                  <p className="text-sm text-[#9bb3c9]">{e.description}</p>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

function FIRTab({ brief }: { brief: string }) {
  return (
    <div className="card p-6">
      <div className="flex items-center gap-2 mb-4">
        <FileText className="w-5 h-5 text-rose-400" />
        <h3 className="text-lg font-bold text-white">FIR-Ready Case Brief</h3>
      </div>
      <pre className="text-sm text-[#c5d4e3] font-mono whitespace-pre-wrap leading-relaxed bg-[#0a1628] p-5 rounded-lg border border-[#1e4064] overflow-x-auto">
        {brief}
      </pre>
    </div>
  )
}

function StatCard({
  label, value, icon: Icon, color, prefix, suffix,
}: {
  label: string
  value: number
  icon: typeof Shield
  color: string
  prefix?: string
  suffix?: string
}) {
  const display = prefix && suffix ? `${prefix}${value.toLocaleString('en-IN')}${suffix}`
    : prefix ? `${prefix}${value.toLocaleString('en-IN')}`
    : suffix ? `${value}${suffix}`
    : value.toLocaleString('en-IN')
  return (
    <div className="card p-4">
      <div className="flex items-center gap-2 mb-2">
        <Icon className={`w-4 h-4 text-${color}-400`} />
        <span className="text-xs text-[#6b8299] font-medium">{label}</span>
      </div>
      <p className="text-2xl font-bold text-white">{display}</p>
    </div>
  )
}
