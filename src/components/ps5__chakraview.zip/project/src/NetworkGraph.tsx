import { useState, useRef, useEffect, useCallback } from 'react'
import { ENTITY_META, REL_META, type EntityType, type RelationshipType } from './lib/fraud'

export type GraphNode = {
  id: string
  label: string
  type: EntityType
  riskScore: number
  role: string
  x: number
  y: number
  vx: number
  vy: number
}

export type GraphEdge = {
  source: string
  target: string
  type: RelationshipType
  amount?: number
}

type Props = {
  nodes: GraphNode[]
  edges: GraphEdge[]
  onNodeClick?: (node: GraphNode) => void
  selectedNode?: string | null
}

const FORCE_CONFIG = {
  repulsion: 800,
  spring: 0.04,
  springLength: 120,
  damping: 0.85,
  centerForce: 0.02,
}

function simulate(nodes: GraphNode[], edges: GraphEdge[], width: number, height: number) {
  const cx = width / 2
  const cy = height / 2

  for (let i = 0; i < nodes.length; i++) {
    const a = nodes[i]
    let fx = 0
    let fy = 0

    fx += (cx - a.x) * FORCE_CONFIG.centerForce
    fy += (cy - a.y) * FORCE_CONFIG.centerForce

    for (let j = 0; j < nodes.length; j++) {
      if (i === j) continue
      const b = nodes[j]
      const dx = a.x - b.x
      const dy = a.y - b.y
      const dist = Math.max(1, Math.sqrt(dx * dx + dy * dy))
      const force = FORCE_CONFIG.repulsion / (dist * dist)
      fx += (dx / dist) * force
      fy += (dy / dist) * force
    }

    for (const edge of edges) {
      if (edge.source === a.id) {
        const b = nodes.find((n) => n.id === edge.target)
        if (b) {
          const dx = b.x - a.x
          const dy = b.y - a.y
          const dist = Math.max(1, Math.sqrt(dx * dx + dy * dy))
          const force = (dist - FORCE_CONFIG.springLength) * FORCE_CONFIG.spring
          fx += (dx / dist) * force
          fy += (dy / dist) * force
        }
      } else if (edge.target === a.id) {
        const b = nodes.find((n) => n.id === edge.source)
        if (b) {
          const dx = b.x - a.x
          const dy = b.y - a.y
          const dist = Math.max(1, Math.sqrt(dx * dx + dy * dy))
          const force = (dist - FORCE_CONFIG.springLength) * FORCE_CONFIG.spring
          fx += (dx / dist) * force
          fy += (dy / dist) * force
        }
      }
    }

    a.vx = (a.vx + fx) * FORCE_CONFIG.damping
    a.vy = (a.vy + fy) * FORCE_CONFIG.damping
    a.x += a.vx
    a.y += a.vy
  }
}

export default function NetworkGraph({ nodes, edges, onNodeClick, selectedNode }: Props) {
  const svgRef = useRef<SVGSVGElement>(null)
  const [dimensions, setDimensions] = useState({ width: 800, height: 500 })
  const [internalNodes, setInternalNodes] = useState<GraphNode[]>([])
  const [hovered, setHovered] = useState<string | null>(null)
  const rafRef = useRef<number>(0)

  useEffect(() => {
    if (!svgRef.current) return
    const rect = svgRef.current.getBoundingClientRect()
    setDimensions({ width: rect.width, height: rect.height })
  }, [])

  useEffect(() => {
    if (nodes.length === 0) return
    const initialized = nodes.map((n, i) => ({
      ...n,
      x: n.x || dimensions.width / 2 + (Math.random() - 0.5) * 200,
      y: n.y || dimensions.height / 2 + (Math.random() - 0.5) * 200,
      vx: 0,
      vy: 0,
    }))
    setInternalNodes(initialized)
  }, [nodes, dimensions])

  useEffect(() => {
    if (internalNodes.length === 0) return
    let frame = 0
    const animate = () => {
      simulate(internalNodes, edges, dimensions.width, dimensions.height)
      setInternalNodes([...internalNodes])
      frame = rafRef.current + 1
      if (frame < 300) {
        rafRef.current = requestAnimationFrame(animate)
      }
    }
    rafRef.current = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(rafRef.current)
  }, [internalNodes, edges, dimensions])

  const handleDrag = useCallback((e: React.MouseEvent, nodeId: string) => {
    if (!svgRef.current) return
    const rect = svgRef.current.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * dimensions.width
    const y = ((e.clientY - rect.top) / rect.height) * dimensions.height
    setInternalNodes((prev) => prev.map((n) => (n.id === nodeId ? { ...n, x, y, vx: 0, vy: 0 } : n)))
  }, [dimensions])

  const hoveredNode = internalNodes.find((n) => n.id === hovered)

  return (
    <div className="relative w-full h-full">
      <svg ref={svgRef} className="w-full h-full" viewBox={`0 0 ${dimensions.width} ${dimensions.height}`}>
        <defs>
          <marker id="arrowhead" markerWidth="8" markerHeight="6" refX="20" refY="3" orient="auto">
            <polygon points="0 0, 8 3, 0 6" fill="#4a6076" />
          </marker>
          <marker id="arrowhead-red" markerWidth="8" markerHeight="6" refX="20" refY="3" orient="auto">
            <polygon points="0 0, 8 3, 0 6" fill="#f43f5e" />
          </marker>
        </defs>

        {edges.map((edge, i) => {
          const source = internalNodes.find((n) => n.id === edge.source)
          const target = internalNodes.find((n) => n.id === edge.target)
          if (!source || !target) return null
          const relMeta = REL_META[edge.type]
          const isHighlighted = hovered === edge.source || hovered === edge.target || selectedNode === edge.source || selectedNode === edge.target
          const midX = (source.x + target.x) / 2
          const midY = (source.y + target.y) / 2
          return (
            <g key={i}>
              <line
                x1={source.x} y1={source.y} x2={target.x} y2={target.y}
                stroke={relMeta.color}
                strokeWidth={isHighlighted ? 2.5 : 1.5}
                strokeOpacity={isHighlighted ? 1 : 0.5}
                strokeDasharray={relMeta.dashed ? '5,3' : undefined}
                markerEnd={edge.type === 'transfers_to' ? 'url(#arrowhead-red)' : 'url(#arrowhead)'}
              />
              {isHighlighted && (
                <text x={midX} y={midY - 4} textAnchor="middle" className="fill-[#9bb3c9] text-[10px] font-medium pointer-events-none">
                  {relMeta.label}
                  {edge.amount ? ` · Rs.${(edge.amount / 1000).toFixed(0)}k` : ''}
                </text>
              )}
            </g>
          )
        })}

        {internalNodes.map((node) => {
          const meta = ENTITY_META[node.type]
          const isHovered = hovered === node.id
          const isSelected = selectedNode === node.id
          const radius = node.riskScore >= 75 ? 22 : node.riskScore >= 50 ? 18 : 14
          const ringColor = node.role === 'kingpin' ? '#f43f5e' : node.role === 'mule' ? '#fbbf24' : node.role === 'victim' ? '#34d399' : '#2a5078'
          return (
            <g key={node.id}
              className="cursor-pointer"
              onMouseEnter={() => setHovered(node.id)}
              onMouseLeave={() => setHovered(null)}
              onMouseDown={(e) => { e.preventDefault(); const move = (ev: MouseEvent) => handleDrag(ev as any, node.id); const up = () => { document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', up) }; document.addEventListener('mousemove', move); document.addEventListener('mouseup', up) }}
              onClick={() => onNodeClick?.(node)}>
              {(isHovered || isSelected) && (
                <circle cx={node.x} cy={node.y} r={radius + 6} fill="none" stroke="#38bdf8" strokeWidth="2" strokeOpacity="0.5" className="animate-pulse" />
              )}
              <circle cx={node.x} cy={node.y} r={radius + 3} fill="none" stroke={ringColor} strokeWidth="2" strokeOpacity={node.role ? 0.8 : 0.3} />
              <circle cx={node.x} cy={node.y} r={radius} fill={`rgba(${colorForMeta(meta.color)}, 0.2)`} stroke={meta.color === 'cyan' ? '#38bdf8' : meta.color === 'emerald' ? '#34d399' : meta.color === 'sky' ? '#38bdf8' : meta.color === 'amber' ? '#fbbf24' : meta.color === 'violet' ? '#a78bfa' : meta.color === 'rose' ? '#f43f5e' : meta.color === 'orange' ? '#fb923c' : '#64748b'} strokeWidth="1.5" />
              <text x={node.x} y={node.y + 1} textAnchor="middle" dominantBaseline="middle" className="pointer-events-none" style={{ fontSize: radius > 18 ? '16px' : '12px' }}>
                {meta.icon}
              </text>
              <text x={node.x} y={node.y + radius + 12} textAnchor="middle" className="fill-white text-[10px] font-medium pointer-events-none" style={{ textShadow: '0 0 4px #0a1628' }}>
                {node.label.length > 14 ? node.label.slice(0, 12) + '...' : node.label}
              </text>
            </g>
          )
        })}
      </svg>

      {hoveredNode && (
        <div className="absolute top-2 right-2 w-56 p-3 rounded-lg bg-[#14365a] border border-cyan-500/40 shadow-xl pointer-events-none z-20">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-lg">{ENTITY_META[hoveredNode.type].icon}</span>
            <span className="text-sm font-semibold text-white">{hoveredNode.label}</span>
          </div>
          <p className="text-xs text-[#9bb3c9]">{ENTITY_META[hoveredNode.type].label}</p>
          <div className="mt-2 flex items-center gap-2">
            <span className="text-xs text-[#6b8299]">Risk:</span>
            <span className={`text-xs font-bold ${hoveredNode.riskScore >= 75 ? 'text-rose-300' : hoveredNode.riskScore >= 50 ? 'text-amber-300' : 'text-sky-300'}`}>
              {hoveredNode.riskScore}/100
            </span>
            {hoveredNode.role && (
              <span className={`badge ${hoveredNode.role === 'kingpin' ? 'bg-rose-500/15 text-rose-300' : hoveredNode.role === 'mule' ? 'bg-amber-500/15 text-amber-300' : 'bg-emerald-500/15 text-emerald-300'} px-2 py-0.5 rounded text-[10px] font-bold uppercase`}>
                {hoveredNode.role}
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

function colorForMeta(color: string): string {
  const map: Record<string, string> = {
    cyan: '56,189,248', emerald: '52,211,153', sky: '56,189,248',
    amber: '251,191,36', violet: '167,139,250', rose: '244,63,94',
    orange: '251,146,60', slate: '100,116,139',
  }
  return map[color] || '100,116,139'
}
